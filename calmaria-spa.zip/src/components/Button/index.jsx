import { StyledButton } from "./styles";
import { Link } from "react-router-dom";

const Button = ({
  children,
  to,
  type,
  variant,
  $formStyle,
  $subscribeStyle,
  $readMoreStyle,
}) => {
  const formProp = $formStyle ?? variant === "form";
  const subscribeProp = $subscribeStyle ?? variant === "subscribe";
  const readMoreProp = $readMoreStyle ?? variant === "read-more";
  if (type === "submit" || type === "button") {
    return (
      <StyledButton
        as="button"
        type={type}
        $formStyle={formProp}
        $subscribeStyle={subscribeProp}
        $readMoreStyle={readMoreProp}
      >
        {children}
      </StyledButton>
    );
  }
  return (
    <StyledButton
      as={Link}
      to={to}
      $formStyle={formProp}
      $subscribeStyle={subscribeProp}
      $readMoreStyle={readMoreProp}
    >
      {children}
    </StyledButton>
  );
};

export default Button;
