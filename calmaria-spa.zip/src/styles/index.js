import theme from "./theme";
import media from "./breakpoints";

export { theme, media };
export default theme;
