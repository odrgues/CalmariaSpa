export const CardsData = [
  {
    id: 1,
    title: "Massagens",
    text: "Relaxantes, terapêuticas, desportivas e drenagens. Conte com nossos terapeutas especializados para aliviar suas tensões, tratar dores e retenção de líquido através dessa técnica milenar tão eficiente para o organismo humano.",
  },
  {
    id: 2,
    title: "Tratamentos Corporais",
    text: "Tratamos sua pele com gentileza através de esfoliações corporais suaves, hidratações profundas do corpo e do rosto, além de limpeza facial. Você também pode desfrutar de banhos revigorantes de sais. ",
  },

  {
    id: 3,
    title: "Dias especias",
    text: "Pacotes cuidadosamente elaborados, desde um  dia revitalizante com massagens e tratamentos faciais, até um dia de serenidade com banhos terapêuticos e meditação. Mime-se com momentos de refúgio e tranquilidade. ",
  },
];
